#!/bin/bash
#SBATCH --job-name=all_block_snip_peft
#SBATCH --output=/export/home/achyut/Sarvesh/sflogs/out_%x_%A_%a.log
#SBATCH --error=/export/home/achyut/Sarvesh/sflogs/err_%x_%A_%a.log
#SBATCH --array=0-999%4
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --time=11:59:59
#SBATCH --mem=220G
#SBATCH --partition=gpu-a100
#SBATCH --gres=gpu:1
#SBATCH --nodelist=node1

# 12 datasets x 22 PEFT configurations x 12 dense-filter positions; no SFT-only runs.
# Total training tasks: 3168. No Caltech101.
# Recommended submission (creates directories and chunks large arrays):
# bash slurm/research_suite/submit_suite.sh --groups 'all_block_snip+peft'
# Direct submission of this script requires creating sflogs first.
# Direct submission runs only the first 1000 tasks; use the submitter for all tasks.
# Early stopping is default. Fixed budget: submit_suite.sh --epochs 100
set -eo pipefail
export SUITE_DIR="${SUITE_DIR:-$SLURM_SUBMIT_DIR/slurm/research_suite}"
source "$SUITE_DIR/config.sh"
if [[ "${DRY_RUN:-0}" != 1 ]]; then
    source ~/.bashrc
    conda activate "$CONDA_ENV"
fi
set -u
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-4}"
mkdir -p "$RESULTS_ROOT/all_block_snip+peft" "$DATA_DIR" "$CACHE_DIR"
preview=()
if [[ "${DRY_RUN:-0}" == 1 ]]; then preview=(--dry-run); fi
python3 -u "$SUITE_DIR/../../tools/research_suite.py" task \
    --group 'all_block_snip+peft' \
    --epochs "$EPOCHS" --seed "$SEED" \
    "${preview[@]}" "$@"
